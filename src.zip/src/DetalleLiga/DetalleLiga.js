import React from 'react'
import { Animated, ImageBackground, ScrollView, TextInput, StyleSheet, Text, View, Image, FlatList, TouchableOpacity, Button } from 'react-native';
import Icon from 'react-native-vector-icons/Ionicons';
import { TabViewAnimated, TabBar, SceneMap } from 'react-native-tab-view';
import { Constants } from 'expo';

import { MatchesRoute } from './Tabs/MatchesRoute';
import { TeamsRoute } from './Tabs/TeamsRoute';

const matchesRoute = () => (
    <MatchesRoute />
);
const teamsRoute = () => (
    <TeamsRoute />
);
const participantsRoute = () => (
    <View style={[styles.container]} />
);

export class DetalleLiga extends React.Component {

    static navigationOptions = {
        header: null,
        tabBarVisible: false,
        swipeEnabled: false,
    };

    state = {
        index: 0,
        routes: [
            { key: 'partidos', title: 'Partidos' },
            { key: 'equipos', title: 'Equipos' },
            { key: 'participantes', title: 'Participantes' },
        ],
    };

    _handleIndexChange = index => this.setState({ index });

    _renderHeader = props => {
        const inputRange = props.navigationState.routes.map((x, i) => i);

        return (
            <View style={styles.tabBar}>
                {props.navigationState.routes.map((route, i) => {
                    const color = props.position.interpolate({
                        inputRange,
                        outputRange: inputRange.map(
                            inputIndex => (inputIndex === i ? '#FFDB31' : 'white')
                        ),
                    });
                    return (
                        <TouchableOpacity
                            style={styles.tabItem}
                            onPress={() => this.setState({ index: i })}>
                            <Animated.Text style={{ color }}>{route.title}</Animated.Text>
                        </TouchableOpacity>
                    );
                })}
            </View>
        );
    };

    _renderScene = SceneMap({
        partidos: matchesRoute,
        equipos: teamsRoute,
        participantes: participantsRoute,
    });

    render() {
        const { goBack } = this.props.navigation;
        return (
            <View style={styles.container}>
                <View style={styles.header}>
                    <View style={styles.joinView}>
                        <TouchableOpacity style={styles.joinBtn}>
                            <View></View>
                            <Text style={styles.joinBtnText}>JOIN</Text>
                            <Icon name="ios-arrow-round-forward" size={20} color="#42444D" />
                        </TouchableOpacity>
                    </View>
                    <ImageBackground
                        style={styles.cardImage}
                        source={{ uri: "https://cdn.vox-cdn.com/thumbor/V3QxnwNKbo3FHi13anmm-7Q3vPk=/0x0:4260x2754/1200x800/filters:focal(1711x1133:2391x1813)/cdn.vox-cdn.com/uploads/chorus_image/image/57194203/862504530.0.jpg" }}
                    >
                        <TouchableOpacity onPress={() => goBack()} style={styles.back}>
                            <Icon name="ios-arrow-round-back" size={32} color='white' />
                        </TouchableOpacity>
                        <View style={[styles.layer, { backgroundColor: "rgba(0,0,0,0.5)" }]}>
                            <Text style={styles.cardText}>
                                Champions League
                            </Text>
                            <View style={{ marginTop: 20, flexDirection: 'row', justifyContent: 'center', alignItems: 'center' }}>
                                <Icon name="ios-person" size={18} color='white' />
                                <Text style={{ color: 'white', marginLeft: 10 }}>12,548</Text>
                            </View>
                        </View>
                    </ImageBackground>
                </View>
                <TabViewAnimated
                    navigationState={this.state}
                    renderScene={this._renderScene}
                    renderHeader={this._renderHeader}
                    onIndexChange={this._handleIndexChange}
                    style={{width: '100%', paddingTop: 40}}
                />
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#42444D',
        alignItems: 'center'
    },
    back: {
        position: 'absolute',
        zIndex: 100,
        marginTop: 28,
        marginLeft: 18
    },
    header: {
        width: '100%',
        height: 250,
        overflow: 'visible'
    },
    title: {
        fontSize: 26,
        marginTop: 22,
        color: 'white',
        padding: 25,
        fontWeight: 'bold'
    },
    cardText: {
        fontSize: 20,
        color: 'white',
        fontWeight: 'bold'
    },
    cardImage: {
        width: '100%',
        height: '100%',
        flex: 1,
    },
    layer: {
        paddingTop: 25,
        width: '100%',
        height: '100%',
        justifyContent: 'center',
        alignItems: 'center'
    },
    joinView: {
        position: 'absolute',
        bottom: -25,
        zIndex: 100,
        width: '100%',
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
    },
    joinBtn: {
        backgroundColor: '#FFDB31',
        borderRadius: 30,
        height: 50,
        width: 200,
        flexDirection: 'row',
        justifyContent: 'space-around',
        alignItems: 'center',
        elevation: 10
    },
    joinBtnText: {
        color: '#42444D',
        fontWeight: 'bold'
    },
    tabBar: {
        flexDirection: 'row',
    },
    tabItem: {
        flex: 1,
        alignItems: 'center',
        padding: 16,
    },
});
