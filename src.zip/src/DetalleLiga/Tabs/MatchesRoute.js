import React from 'react';
import { ScrollView, ImageBackground, StyleSheet, View, Text, Button, AsyncStorage } from 'react-native';
import { MapView, Marker } from 'expo';
import Icon from 'react-native-vector-icons/Ionicons';

import { Match } from './Match';

export class MatchesRoute extends React.Component {

    constructor(props) {
        super(props);
    }

    componentDidMount() {

    }

    render() {
        return (
            <ScrollView style={styles.container}>
                <Match match={{home: 'Real Madrid', away: 'Liverpool', time: '21:45', stadium: 'Estadio Olímpico, Kiev'}}/>
                <Match match={{home: 'Real Madrid', away: 'Liverpool', time: '21:45', stadium: 'Estadio Olímpico, Kiev'}}/>
                <Match match={{home: 'Real Madrid', away: 'Liverpool', time: '21:45', stadium: 'Estadio Olímpico, Kiev'}}/>
                <Match match={{home: 'Real Madrid', away: 'Liverpool', time: '21:45', stadium: 'Estadio Olímpico, Kiev'}}/>
                <Match match={{home: 'Real Madrid', away: 'Liverpool', time: '21:45', stadium: 'Estadio Olímpico, Kiev'}}/>
            </ScrollView>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#42444D',
        padding: 16
    }
});
