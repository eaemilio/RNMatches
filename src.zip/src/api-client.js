const URL = 'https://protected-fjord-14633.herokuapp.com/api';

getLeagues = async () => {
    return await fetch(URL + '/leagues')
        .then(response => response.json());
}

export {
    getLeagues,
}